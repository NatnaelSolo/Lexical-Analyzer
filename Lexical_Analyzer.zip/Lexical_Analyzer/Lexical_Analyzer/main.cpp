
#include <iostream>
#include <string>
using namespace std;

// Flex doesn't play well with unistd.h on some systems
#define YY_NO_UNISTD_H




"if"|"else"|"while"|"for"|"int"|"float" { cout << "KEYWORD: " << yytext << endl; }
[a-zA-Z][a-zA-Z0-9]*                    { cout << "IDENTIFIER: " << yytext << endl; }
[0-9]+                                  { cout << "NUMBER: " << yytext << endl; }
[0-9]+\.[0-9]+                          { cout << "FLOAT: " << yytext << endl; }
[-+*/=<>]                               { cout << "OPERATOR: " << yytext << endl; }
[ \t\n]+                                { /* Ignore whitespace */ }
.                                       { cout << "UNKNOWN: " << yytext << endl; }

int main() {
    yylex();
    return 0;
}
